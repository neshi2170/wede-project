/* main.js
   - Form validation + AJAX placeholder
   - Mobile menu toggle
   - Simple image slider for .gallery
   - Lazy-loading fallback via IntersectionObserver
*/

document.addEventListener('DOMContentLoaded', function () {

  /* ---------- Mobile menu toggle (if you have a .nav-toggle and .nav) ---------- */
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('nav');
  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      nav.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', nav.classList.contains('open'));
    });
  }

  /* ---------- Smooth scroll for anchor links ---------- */
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', function (e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  /* ---------- Lazy loading fallback (adds 'loading=lazy' where missing) ---------- */
  if ('IntersectionObserver' in window) {
    const lazyImgs = document.querySelectorAll('img[data-src]');
    const io = new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target;
          img.src = img.dataset.src;
          img.removeAttribute('data-src');
          obs.unobserve(img);
        }
      });
    }, { rootMargin: "100px" });

    lazyImgs.forEach(img => io.observe(img));
  } else {
    // fallback: load all images
    document.querySelectorAll('img[data-src]').forEach(img => {
      img.src = img.dataset.src;
    });
  }

  /* ---------- Simple accessible slider for .gallery ---------- */
  (function setupGallery() {
    const gallery = document.querySelector('.gallery');
    if (!gallery) return;
    const slides = Array.from(gallery.querySelectorAll('.slide'));
    let idx = 0;

    function show(i) {
      slides.forEach((s, si) => {
        s.style.display = si === i ? 'block' : 'none';
      });
    }
    // create nav controls
    const prev = document.createElement('button'); prev.className = 'g-prev'; prev.textContent = '‹';
    const next = document.createElement('button'); next.className = 'g-next'; next.textContent = '›';
    gallery.appendChild(prev); gallery.appendChild(next);
    prev.addEventListener('click', () => { idx = (idx - 1 + slides.length) % slides.length; show(idx); });
    next.addEventListener('click', () => { idx = (idx + 1) % slides.length; show(idx); });
    show(idx);
  })();

  /* ---------- Form validation + submit ---------- */
  const form = document.getElementById('enquiryForm');
  if (form) {
    form.addEventListener('submit', async function (e) {
      e.preventDefault();
      clearErrors();

      const values = {
        name: form.name.value.trim(),
        email: form.email.value.trim(),
        phone: form.phone.value.trim(),
        message: form.message.value.trim(),
        service: form.service ? form.service.value : ''
      };

      const errors = {};
      if (!values.name || values.name.length < 2) errors.name = 'Please enter your full name.';
      if (!values.email || !/^\S+@\S+\.\S+$/.test(values.email)) errors.email = 'Please enter a valid email.';
      if (values.phone && !/^[\d +()\-]{7,20}$/.test(values.phone)) errors.phone = 'Please enter a valid phone number.';
      if (!values.message || values.message.length < 8) errors.message = 'Please enter a short message (at least 8 characters).';

      if (Object.keys(errors).length) {
        showErrors(errors);
        return;
      }

      // Show busy state
      const status = document.getElementById('form-status');
      status.textContent = 'Sending…';
      try {
        // Replace with your server endpoint
        const resp = await fetch('https://example.com/api/enquiry', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(values)
        });

        if (resp.ok) {
          status.textContent = 'Thank you — your enquiry was sent.';
          form.reset();
        } else {
          status.textContent = 'Sorry, something went wrong. Please email us at info@yourdomain.example';
        }
      } catch (err) {
        status.textContent = 'Network error. Please check your connection and try again.';
      }
    });

    function clearErrors() {
      ['name', 'email', 'phone', 'message'].forEach(k => {
        const el = document.getElementById('err-' + k);
        if (el) el.textContent = '';
      });
    }
    function showErrors(errors) {
      Object.keys(errors).forEach(k => {
        const el = document.getElementById('err-' + k);
        if (el) el.textContent = errors[k];
      });
    }
  } // end if form
});


